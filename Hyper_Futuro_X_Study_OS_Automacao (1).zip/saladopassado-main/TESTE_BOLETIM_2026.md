# Teste do boletim de 2026

O login original da SED pode não fornecer `AlunoId`. Para testar, abra o cartão Notas no Hyper e digite **somente o AlunoId da sua própria conta** obtido no DevTools > Network > GetAvaliacaoAluno no site oficial. O campo é opcional quando o login já retorna o identificador. Não há ID fixado no código, e o ID preenchido não é armazenado em disco ou localStorage.

A rota POST `/api/hyper/boletim/teste` faz somente leitura na API oficial com o token SED da sessão. Uma resposta HTTP 200 confirma apenas a leitura; o formato das disciplinas e notas ainda precisa ser mapeado. Uma resposta 401/403 indica autenticação ou permissão incompatível, não deve ser contornada.

O projeto mantém as APIs originais de Tarefas, Redação, Matific e LeiaSP.
