# Hyper — integração de APIs escolares

As rotas `/api/school/{profile,disciplines,attendance,grades,agenda,notifications,achievements}` estão presentes como consultas **somente leitura** no backend.

Elas usam a sessão autenticada existente e retornam `available:false` quando faltam IDs, permissão ou resposta válida. Não substitua `codigoAluno` por RA: são identificadores diferentes.

**Não há garantia** de acesso: métodos, escopos, permissões e formatos dos endpoints fornecidos não foram confirmados por documentação pública. Nenhuma nota ou falta é inventada. O boletim/frequência agora mostram a resposta não formatada se houver uma resposta válida: é necessário mapear seu schema real para formatar cartões por matéria.

Firebase e Azure não foram integrados porque não fornecem dados escolares necessários. Não coloque tokens no HTML.

Os fluxos antigos de TarefaSP, Redação, Matific e LeiaSP foram mantidos sem mudanças. Teste o login e a API com credenciais autorizadas no seu computador, sem compartilhar senhas ou tokens.
