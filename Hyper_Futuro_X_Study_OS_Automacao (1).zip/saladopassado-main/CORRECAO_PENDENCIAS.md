# Correção do contador de pendências

A página inicial agora consulta `/api/tasks/pending-summary`, que reaproveita as respostas reais de `/api/tasks` usadas nas abas Tarefas e Redação. Itens explicitamente concluídos ou expirados são excluídos. A interface mostra os totais de tarefas e redações separadamente. Não utiliza o total bruto de 28 atividades e não inventa a contagem 2.

**Limitação:** a lista das atividades deve vir da sessão escolar válida. Se o serviço não retornar as tarefas, o painel indicará erro. Itens com metadados incompletos podem diferir dos filtros do site oficial. Verifique em sua sessão autenticada.

**Testes executados:** sintaxe de arquivos Python e JavaScript, checagem básica de classificação e integridade ZIP. Não foi realizado login real na SED.
