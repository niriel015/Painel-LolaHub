# Hyper Futuro X — consultas escolares oficiais

## Correções
- Boletim consulta `ConsultaFechamentoComparativo` com tipos 5, 6, 7 e 8; mapeia para 1º–4º bimestres.
- Mostra `notaAtribuida` e `notaMediaTurma` sem calcular médias finais não confirmadas.
- Um retorno `data: []` é exibido como período sem notas disponíveis, nunca zero.
- A janela Faltas chama `GetFaltasBimestreAtual` e rotula os números como bimestre atual (não ano inteiro).
- A consulta de boletim registra na sessão códigos de turma e escola obtidos da resposta autorizada, mas **não inventa nomes**.
- Se o login não entregar AlunoId, em Configurações > Dados do aluno aparece campo para informar o próprio AlunoId. O servidor só vincula após comparar RA e dígito do fechamento oficial com os da sessão atual. Não grava o código no projeto nem em arquivo.
- Preserva o contador anterior de pendências e o painel existente.

## Limites ainda dependentes de verificação real
- Não foi possível executar chamadas oficiais autenticadas nesta revisão, porque não há sessão da SED disponível no ambiente de teste.
- As APIs observadas retornam códigos da turma e escola, porém não seus nomes; o painel exibirá esses códigos até identificar rotas confiáveis de descrição da escola/turma.
- O código de aluno pode ser extraído automaticamente se a autenticação trouxer campo explicitamente marcado como identificador de aluno; caso contrário precisa de vinculação manual validada na SED.
- As respostas e credenciais da SED não estão incluídas no ZIP.

## Execução
Na pasta `saladopassado-main`: `python -m uvicorn app:app --reload`.
Após login vá em Configurações para verificar se `AlunoId` foi recebido. Em caso negativo, vincule-o usando o código do **seu próprio boletim**. Abra Notas e Faltas para realizar consultas.
