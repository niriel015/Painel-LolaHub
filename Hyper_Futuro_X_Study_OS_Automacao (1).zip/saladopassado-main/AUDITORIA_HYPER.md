# Hyper Futuro X — revisão de integridade (12/11/2026)

## Verificações realizadas
- ZIP original: integridade de todos os membros comprovada.
- Código Python: todos os arquivos `.py` compilados sintaticamente.
- JavaScript: blocos inline e arquivos `.js` testados sintaticamente com Node.js.
- Pastas e rotas: checadas contra a estrutura de extração e caminhos usados pelo servidor.
- Código original de tarefas, redações, Matific e LeiaSP preservado.

## Correções efetuadas
1. `app.py`: o bloco que chama `uvicorn.run()` foi movido para o fim do arquivo, depois do registro de todas as rotas; isso também corrige a forma `python app.py`.
2. Autenticação: procura por identificador **explicitamente rotulado como aluno** tanto na resposta de login quanto, quando existir, nas alegações do token; nunca converte `CD_USUARIO` em `AlunoId` por suposição.
3. Saudação: removida a rotina duplicada que substituía “Boa tarde, [primeiro nome]” pelo nome inteiro.
4. Consultas escolares: mensagens mais claras quando o login não fornece o código escolar. Não apresenta notas, faltas nem turma fictícias.
5. Exibição técnica: filtragem adicional de identificadores e nomes de aluno nas respostas JSON de diagnóstico.

## Limites confirmados (não é possível declarar 100% funcional)
- O `/api/me` pode responder 200 com nome e RA mas sem `student_id`. A resposta `ExibirAluno` fornecida nesta conversa **não contém** esse ID; a resposta `ObterInformacaoAluno` depende do ID como parâmetro. Sem um campo explícito no login, o backend não tem como obter ou inferir corretamente o código apenas a partir desses endpoints.
- O JSON `ObterInformacaoAluno` compartilhado **não contém nome da turma nem da escola**. Os dados de série/diretoria não identificam a letra da turma nem o nome completo da unidade.
- O contador oficial `/api/tasks/pending-count` usa a API `tms/task/todo/count`. O retorno e credenciais da plataforma exigem teste em sessão real; o serviço pode estar indisponível.
- Os cartões de notas/faltas dependem do formato real das respectivas APIs, ainda não integralmente fornecido. Não foram realizados testes autenticados nem acessados dados privados.
- O original contém chave de integração SED no `config.py`, no cliente LeiaSP e no exemplo `.env`. Como foi exposta na conversa, recomenda-se substituir/revogar conforme a administração do serviço. A chave foi mantida por compatibilidade nesta versão, mas não deve ser publicada em repositórios públicos.
- A aplicação original contém rotinas de resolução automática de atividades. Foram preservadas, não expandidas nem validadas nesta revisão.

## Executar
Abra a pasta `saladopassado-main` e instale `python -m pip install -r requirements.txt`, depois `python -m uvicorn app:app --reload`. O requisito `httpcloak` pode exigir instalação conforme o ambiente. Use Ctrl+Shift+R após trocar a versão.
