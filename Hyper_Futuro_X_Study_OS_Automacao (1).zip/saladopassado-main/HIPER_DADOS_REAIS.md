# Integração escolar: somente dados reais

- `/api/me` apresenta os campos confirmados pela sessão. `school_series` só é preenchido por `outAluno.outSerie` da resposta autenticada.
- A frequência usa `data[0].totalFaltasBimestre`, `totalAulasRealizadas` e `porcentagemFrequencia`, nunca um valor de demonstração.
- Boletim: somente avaliações recebidas, sem inventar médias.
- Avisos: foi removida a cópia dos dois comunicados antigos; sem resposta autorizada, a tela mostra indisponível.
- A consulta oficial de dados escolares exige `AlunoId` ou `cdAluno`. O token SED frequentemente traz `CD_USUARIO`, **que não foi presumido como `AlunoId`**. Logo, sem identificador escolar expresso pelo provedor, turma, boletim e faltas podem continuar indisponíveis.
- O endpoint privado de terceiros `/api/me` do Zunder não foi integrado.
- O projeto não inclui IDs de aluno ou credenciais pessoais fixos.
- Testes automatizados de estrutura e sintaxe não representam uma sessão autenticada ao vivo.
