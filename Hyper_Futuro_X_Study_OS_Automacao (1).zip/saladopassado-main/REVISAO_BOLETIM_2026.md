# Revisão do boletim 2026

- Corrigida a projeção de respostas `GetAvaliacaoAluno`: todos os registros (limite técnico 3000) em vez de truncar aos 60 primeiros.
- A API do Hyper retorna somente campos necessários para exibir avaliações e retira identificadores pessoais.
- Organizados cartões de avaliações por disciplina (código até que a API de nomes de disciplinas esteja conectada) e filtros 1º–4º bimestres.
- Notas nulas são exibidas como "Sem nota"; nota zero continua sendo mostrada como 0.
- Não é calculada média/aprovação a partir de notas individuais sem regra de cálculo validada.
- Nenhum dado pessoal da resposta fornecida foi incluído no projeto.
- A consulta requer que o login forneça o código escolar e autenticação SED válidos. Não é garantida conectividade real até o teste em sessão autenticada.
