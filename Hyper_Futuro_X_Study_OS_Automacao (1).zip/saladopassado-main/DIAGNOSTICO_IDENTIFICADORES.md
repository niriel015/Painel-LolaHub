# Diagnóstico de AlunoId no Hyper

Esta revisão amplia a leitura dos campos de aluno fornecidos **explicitamente** pelo login (inclusive JSON aninhado em strings). Não presume que `CD_USUARIO` seja `AlunoId`.

Depois de entrar, consulte `http://127.0.0.1:8000/api/hyper/escolar/diagnostico-identificadores`. O endpoint mostra somente **nomes de campos** e indicadores booleanos, não retorna valores de RA, IDs, CPF, senha ou tokens.

Se `codigo_aluno_encontrado` for `false`, ainda falta uma fonte autorizada para mapear a sessão ao código de aluno usado no boletim. Não se garante a sincronização de notas e faltas nesse caso.

As APIs originais e o layout foram mantidos.
