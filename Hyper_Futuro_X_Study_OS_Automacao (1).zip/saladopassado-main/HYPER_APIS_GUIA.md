# Hyper Futuro X — APIs da Sala do Futuro

## Como usar

1. Instale `requirements.txt` e execute `python -m uvicorn app:app --reload` dentro de `saladopassado-main`.
2. Faça login pelo formulário já existente. Não cole tokens de outra sessão.
3. Abra **Desempenho → Dados escolares oficiais** para testar as consultas.
4. Em Início → Notas, o Hyper tenta consultar o boletim, sem exigir código digitado.

## Estado das integrações

O backend inclui apenas consultas GET para recursos da lista do Network: perfil, informações escolares, boletim, faltas, agenda, disciplinas, notificações, avatar, conquistas, avisos, conteúdos, monitor, parâmetros e configurações.

- As integrações de tarefas, redação, Matific e LeiaSP **originais** continuam instaladas.
- Endpoints de telemetria (Azure, Google Analytics, Clarity) e configuração de Firebase não são dados escolares e não foram replicados.
- `registrar-usuario-token` não é consulta GET e **não foi executado**: não há documentação confirmando método e payload.
- Links da EduSP (`todo/count`, `adaptive-assessment`, etc.) dependem de `publication_target` da sessão e já têm implementações parciais no cliente original. Não foram substituídos por parâmetros fixos de outra conta.
- `AlunoId` (para notas) e `UsuarioId` (para avisos) são **identificadores diferentes**. Não são inferidos um do outro: se não vierem no login, o app informa o problema.
- O campo `CD_USUARIO` é lido do token obtido *pela sessão autenticada*; não é enviado para o HTML.
- Não há garantia de retorno 200: o serviço pode exigir credenciais/permissões específicas ou um código de aluno ausente.
- Respostas exibidas são limitadas e filtradas para não mostrar CPF, telefone, endereço, tokens e senhas.
- A apresentação das notas ainda depende de confirmar o esquema JSON exato da API.

## Segurança

Não envie JWTs, cookies, HAR ou chaves de assinatura de API. A identidade utilizada vem somente da sessão autenticada.
